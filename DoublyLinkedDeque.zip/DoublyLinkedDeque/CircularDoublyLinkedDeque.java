package assignment04PartD;

import java.util.function.DoubleUnaryOperator;

public class CircularDoublyLinkedDeque<T> implements DequeInterface<T> {
    private DoublyLinkedNode front;
    private static int numberOfEntries=0;

    @Override
    public void addToFront(T newEntry) {
        DoublyLinkedNode newNode =  new DoublyLinkedNode(newEntry);
        if (numberOfEntries==0){
            front=newNode;
        }else{
            newNode.next=front;
            front.pre=newNode;
            front=newNode;
        }


        numberOfEntries++;


    }

    @Override
    public void addToBack(T newEntry) {
        DoublyLinkedNode newNode =  new DoublyLinkedNode(newEntry);
        if (front==null){
            front=newNode;
        }else{
            DoublyLinkedNode current = front;
            while (current.next!= null){
                current=current.next;
            }
            current.next=newNode;
            newNode.pre=current;
        }numberOfEntries++;

    }

    @Override
    public T removeFront() {
        DoublyLinkedNode current = front;
        if ((isEmpty())||(current==null)) {
            throw  new EmptyQueueException("The Stack is Empty");
        } else if((current.next==null)){ // this scenario
            DoublyLinkedNode ha= front;
            current=null;
            numberOfEntries--;

            return ha.data;
        } else{
            DoublyLinkedNode ha= front;
            current.next.pre=null;
            front=current.next;

            numberOfEntries--;
            return ha.data;
        }
    }

    @Override
    public T removeBack() {
        DoublyLinkedNode current = front;
        if (isEmpty()) {
            throw  new EmptyQueueException("The Stack is Empty");
        }else{
            while (current.next!=null){
                current=current.next;
            }
            DoublyLinkedNode need= current.pre.next;
            current.pre.next=null;

            numberOfEntries--;
            return need.data;
        }    }

    @Override
    public T getFront() {
        if (isEmpty()) {
            throw new EmptyQueueException("The Stack is Empty");
        } else {
            return front.data;
        }
    }

    @Override
    public T getBack() {
        if (isEmpty()){
            throw new EmptyQueueException("The Stack is Empty");
        }else {
            DoublyLinkedNode current = front;
            while (current.next!=null){
                current=current.next;
            }
            return current.data;

        }

    }

    @Override
    public boolean isEmpty() {
        return numberOfEntries==0;
    }

    @Override
    public void clear() {
        for (int i=0;i<numberOfEntries;i++){
            removeFront();
        }

    }

    private class DoublyLinkedNode {
        DoublyLinkedNode next ;
        DoublyLinkedNode pre;
        T data;

        DoublyLinkedNode(T data, DoublyLinkedNode next, DoublyLinkedNode pre){
            this.data=data;
            this.next=next;
            this.pre=pre;

        }DoublyLinkedNode(T data){
            this(data,null,null);

        }



    } // end DoublyLinkedNode

} // end CircularDoublyLinkedDeque
