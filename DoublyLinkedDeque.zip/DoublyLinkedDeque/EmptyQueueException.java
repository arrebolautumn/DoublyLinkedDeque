package assignment04PartD;
import java.util.*;
/**
 *
 * Part D
 *
 */

public class EmptyQueueException extends RuntimeException {
    private String message="Empty Stack";
    public EmptyQueueException(){
        super("Doubly Linked Chain is Empty");
    }public EmptyQueueException(String message){
        super(message);
        this.message=message;
    }public String getMessage(){
        return  this.message;
    }
    /* testing :
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter an Age: ");
            int age = input.nextInt();

            if ((age <18)||(age>110)){
                throw new EmptyQueueException("Are you kidding me?");

            }
        }catch (EmptyQueueException ex){
            System.out.println(ex.getMessage());

        }
    }*/

} // end EmptyQueueException